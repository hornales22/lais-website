
// Accessibility friendly mobile nav toggle
const navToggle = document.querySelector('.nav-toggle');
const nav = document.querySelector('#primary-nav');
if (navToggle && nav) {
  navToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    navToggle.setAttribute('aria-expanded', open);
  });
}

// Dynamic year
const yearEl = document.getElementById('year');
if (yearEl) yearEl.textContent = new Date().getFullYear();

// Load announcements & events from data JSON
async function loadHomeData(){
  try{
    const res = await fetch('/data/home.json');
    if(!res.ok) throw new Error('Failed to load home data');
    const data = await res.json();
    const annEl = document.getElementById('announcements');
    const evtEl = document.getElementById('events');
    data.announcements.forEach(a=>{
      const li = document.createElement('li');
      li.innerHTML = `<strong>${a.title}</strong> — <span>${a.date}</span><br/><span class="muted">${a.summary}</span>`;
      annEl && annEl.appendChild(li);
    });
    data.events.forEach(e=>{
      const li = document.createElement('li');
      li.innerHTML = `<strong>${e.title}</strong> — ${e.date} @ ${e.venue}`;
      evtEl && evtEl.appendChild(li);
    });
  }catch(e){console.warn(e)}
}
loadHomeData();

// News loader
async function loadNews(){
  const holder = document.getElementById('newsList');
  if(!holder) return;
  try{
    const res = await fetch('/data/news.json');
    if(!res.ok) throw new Error('Failed to load news');
    const {news} = await res.json();
    news.forEach(n=>{
      const card = document.createElement('article');
      card.className = 'news-card';
      card.innerHTML = `
        <h3>${n.title}</h3>
        <p class="muted">${n.date}</p>
        <p>${n.summary}</p>
        ${n.link ? `<a class="btn" href="${n.link}">Read more</a>` : ''}
      `;
      holder.appendChild(card);
    });
  }catch(e){console.warn(e)}
}
loadNews();

// Mock submit handlers (no backend required)
function formHandler(formId, msgId){
  const form = document.getElementById(formId);
  const msg = document.getElementById(msgId);
  if(!form || !msg) return;
  form.addEventListener('submit', (ev)=>{
    ev.preventDefault();
    const data = new FormData(form);
    const name = data.get('studentName') || data.get('name') || 'Your submission';
    msg.textContent = `${name} submitted successfully. We will contact you shortly.`;
    form.reset();
  });
}
formHandler('applyForm','applyMsg');
formHandler('contactForm','contactMsg');
